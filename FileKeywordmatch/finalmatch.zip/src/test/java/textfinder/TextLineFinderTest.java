package textfinder;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import junit.framework.Assert;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class TextLineFinderTest {

	TextLineFinder textLineFinder = null;

	String searchString;

	File source1;

	File source2;

	@Before
	public void setup() {
		String srcPathForkeyWord = null;
		String srcPathToSearchFile = null;
		searchString = "dhanraj";
		// String srcPathForkeyWord = "C:/dhanaraj/test1.txt";
		URL url = this.getClass().getResource("test1.txt");
		//System.out.println(url.getPath());
		srcPathForkeyWord = url.getPath();
		// srcPathToSearchFile = "C:/dhanaraj/test.txt";
		url = null;
		url = this.getClass().getResource("test.txt");
		//System.out.println(url.getPath());
		srcPathToSearchFile = url.getPath();
		source2 = new File(srcPathForkeyWord);
		source1 = new File(srcPathToSearchFile);

		textLineFinder = TextLineFinder.getTextLineFinderInstance();
	}

	@Test
	public void testGetAllFileTxtLine() throws IOException {

		Map<String, List<Integer>> map = textLineFinder.getAllFileTxtLine(
				"dhanaraj", source1, source2);

		Assert.assertNotNull("map is null.." + map);

		Assert.assertEquals("Search word not found...", 1,
				((List<Integer>) map.get("dhanaraj")).get(0).intValue());

	}

	@Test
	public void getKeyWordsInMap() throws IOException {
		HashMap<String, List<Integer>> mp = new HashMap<String, List<Integer>>();
		List<Integer> lineList = new ArrayList<Integer>();
		lineList.add(1);
		lineList.add(2);
		mp.put("test", lineList);
		textLineFinder.getKeyWordsInMap(source2, mp, "dhanaraj");
		Assert.assertEquals("Search word list", 1, mp.size());

		textLineFinder.getKeyWordsInMap(source2, mp, null);
		Assert.assertEquals("Search word list", 3, mp.size());

	}

	@Test
	public void printMap() {
		HashMap<String, List<Integer>> mp = new HashMap<String, List<Integer>>();
		List<Integer> lineList = new ArrayList<Integer>();
		lineList.add(1);
		lineList.add(2);
		mp.put("test", lineList);
		textLineFinder.printMap(mp);

	}

	@After
	public void tearDown() {
		textLineFinder = null;

	}

}
